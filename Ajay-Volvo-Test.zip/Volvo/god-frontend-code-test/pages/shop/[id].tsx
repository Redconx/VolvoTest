import React from 'react';
import { useRouter } from 'next/router';
import { View, Link, Text } from 'vcc-ui';

const Shop = () => {
    const router = useRouter();
    const { id } = router.query;

    return (
        <View>
            <Text> Shop {id}</Text>
            <Link type="button" onClick={() => router.back()}>
                go back
            </Link>
        </View>
    );
};

export default Shop;
