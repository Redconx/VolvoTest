import React from 'react';
import { AppProps } from 'next/app';
import { StyleProvider, ThemePicker } from 'vcc-ui';
import '../src/css/styles.css';
import {FilterCarModelProvider } from '../src/context/FilterCarModelProvider';

const HomePage = ({ Component, pageProps }: AppProps) => {
    return (
        <StyleProvider>
            <ThemePicker>
                <React.StrictMode>
                    <FilterCarModelProvider>
                        <Component {...pageProps} />
                    </FilterCarModelProvider>
                </React.StrictMode>
            </ThemePicker>
        </StyleProvider>
    );
};

export default HomePage;
