import { NextApiResponse, NextApiRequest } from 'next';
import cars from '../../public/api/cars.json';
import { Car } from '../../src/utils/interfaces/cars';

export default function getAllCars(_req: NextApiRequest, res: NextApiResponse<Car[]>) {
    return res.status(200).json(cars);
}
