import React, { useContext, useMemo } from 'react';
import { Flex, Spinner, Text, Block, View } from 'vcc-ui';
import Head from 'next/head';
import useSWR from 'swr';
import { fetcher } from '../src/utils/fetcher';
import { Car } from '../src/utils/interfaces/cars';
import { CarComponent } from '../src/components/CarCard/CarComponent';
import FilterDropDown from '../src/components/CustomDropDown/FilterDropDown';
import { FilterCarModelContext } from '../src/context/FilterCarModelProvider';
import { getFilteredCars } from '../src/utils/filterCarByBodyType';
import CustomSearchInput from '../src/components/CustomSearchInput/CustomSearchInput';
import { container, title, filterContainer, filterWrapper } from '../src/components/styles/home.styles';
import useDebounce from '../src/hooks/useDebounce';

const Home: React.FC = () => {
    const { selectedBodyType, queryString } = useContext(FilterCarModelContext);
    const { data, error, isLoading } = useSWR<Car[]>('/api/cars', fetcher);

    // Debounce the search query
    const debouncedQuery = useDebounce(queryString, 100);

    // we extract and memoize body types
    const carBodyTypes = useMemo(() => data?.map(({ bodyType }) => bodyType), [data]);
    const bodyTypes = [...new Set(carBodyTypes)];

    //we filter cars based on body type and search query and memoise them
    const filteredResult = useMemo(() => {
        const byBodyType = getFilteredCars(data, selectedBodyType);
        if (!debouncedQuery) return byBodyType;

        return byBodyType.filter(car =>
            car.modelName.toLowerCase().includes(debouncedQuery.toLowerCase())
        );
    }, [data, selectedBodyType, debouncedQuery]);

    // Error handling
    if (error) {
        return (
            <View role='alert'>
                <Text>
                    Sorry, something went wrong. Please try again.
                </Text>
            </View>
        );
    }

    // Loader during API call
    if (isLoading) {
        return (
            <View aria-busy="true" aria-live="polite">
                <Flex extend={{ justifyContent: 'center', alignItems: 'center' }} >
                    <Spinner size={40} />
                    <Text>
                        Loading please wait...
                    </Text>
                </Flex>
            </View>
        );
    }
    // If data not found
    if (!data) {
        return (
            <Text subStyle="emphasis" as="h1" extend={title}>
                Volvo Cars are not available
            </Text>
        );
    }

    return (
        <>
            <Head>
                <title>Volvo electric Cars - Recharge | Volvo Cars </title>
                <meta name="description" content="Check out Volvo Cars Recharge. Visit Volvo cars digital shop." key="desc" />
                <meta name="author" content="Volvo" />
                <meta name="keywords" content="html,css,react,nextjs,typescript" />
                <meta name="theme-color" media="(prefers-color-scheme: light)" content="cyan" />
                <link rel="shortcut icon" href="/favicon.ico" />
            </Head>

            <main>
                <Block extend={container}>
                    <h1>
                        Volvo electric Cars - Recharge!
                    </h1>
                </Block>
                <Block extend={filterContainer}>
                    <Flex extend={filterWrapper}>
                        <FilterDropDown bodyTypes={bodyTypes} />
                        <CustomSearchInput />
                    </Flex>
                    <CarComponent cars={filteredResult} />
                </Block>
            </main>
        </>
    );
};

export default Home;
