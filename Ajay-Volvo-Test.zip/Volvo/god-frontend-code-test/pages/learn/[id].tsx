import React from 'react';
import { useRouter } from 'next/router';
import { View, Link, Flex, Text } from 'vcc-ui';

const Learn = () => {
    const router = useRouter();
    const { id } = router.query;

    return (
        <Flex extend={{}}>
            <Text> Learn about {id}</Text>
            <Link type="button" onClick={() => router.back()}>
                Back
            </Link>
        </Flex>
    );
};

export default Learn;
