/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./pages/_app.tsx":
/*!************************!*\
  !*** ./pages/_app.tsx ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var vcc_ui__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vcc-ui */ \"vcc-ui\");\n/* harmony import */ var vcc_ui__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(vcc_ui__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _src_css_styles_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../src/css/styles.css */ \"./src/css/styles.css\");\n/* harmony import */ var _src_css_styles_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_src_css_styles_css__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _src_context_FilterCarModelProvider__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../src/context/FilterCarModelProvider */ \"./src/context/FilterCarModelProvider.tsx\");\n\n\n\n\n\nconst HomePage = ({ Component , pageProps  })=>{\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(vcc_ui__WEBPACK_IMPORTED_MODULE_2__.StyleProvider, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(vcc_ui__WEBPACK_IMPORTED_MODULE_2__.ThemePicker, {\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((react__WEBPACK_IMPORTED_MODULE_1___default().StrictMode), {\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_src_context_FilterCarModelProvider__WEBPACK_IMPORTED_MODULE_4__.FilterCarModelProvider, {\n                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                        ...pageProps\n                    }, void 0, false, {\n                        fileName: \"/Users/creware/Desktop/Volvo/god-frontend-code-test/pages/_app.tsx\",\n                        lineNumber: 13,\n                        columnNumber: 25\n                    }, undefined)\n                }, void 0, false, {\n                    fileName: \"/Users/creware/Desktop/Volvo/god-frontend-code-test/pages/_app.tsx\",\n                    lineNumber: 12,\n                    columnNumber: 21\n                }, undefined)\n            }, void 0, false, {\n                fileName: \"/Users/creware/Desktop/Volvo/god-frontend-code-test/pages/_app.tsx\",\n                lineNumber: 11,\n                columnNumber: 17\n            }, undefined)\n        }, void 0, false, {\n            fileName: \"/Users/creware/Desktop/Volvo/god-frontend-code-test/pages/_app.tsx\",\n            lineNumber: 10,\n            columnNumber: 13\n        }, undefined)\n    }, void 0, false, {\n        fileName: \"/Users/creware/Desktop/Volvo/god-frontend-code-test/pages/_app.tsx\",\n        lineNumber: 9,\n        columnNumber: 9\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HomePage);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBQUE7QUFBMEI7QUFFMEI7QUFDckI7QUFDK0M7QUFFOUUsTUFBTUksUUFBUSxHQUFHLENBQUMsRUFBRUMsU0FBUyxHQUFFQyxTQUFTLEdBQVksR0FBSztJQUNyRCxxQkFDSSw4REFBQ0wsaURBQWE7a0JBQ1YsNEVBQUNDLCtDQUFXO3NCQUNSLDRFQUFDRix5REFBZ0I7MEJBQ2IsNEVBQUNHLHVGQUFzQjs4QkFDbkIsNEVBQUNFLFNBQVM7d0JBQUUsR0FBR0MsU0FBUzs7Ozs7aUNBQUk7Ozs7OzZCQUNQOzs7Ozt5QkFDVjs7Ozs7cUJBQ1Q7Ozs7O2lCQUNGLENBQ2xCO0NBQ0w7QUFFRCxpRUFBZUYsUUFBUSxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZnJvbnRlbmQtY29kZS10ZXN0Ly4vcGFnZXMvX2FwcC50c3g/MmZiZSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgQXBwUHJvcHMgfSBmcm9tICduZXh0L2FwcCc7XG5pbXBvcnQgeyBTdHlsZVByb3ZpZGVyLCBUaGVtZVBpY2tlciB9IGZyb20gJ3ZjYy11aSc7XG5pbXBvcnQgJy4uL3NyYy9jc3Mvc3R5bGVzLmNzcyc7XG5pbXBvcnQge0ZpbHRlckNhck1vZGVsUHJvdmlkZXIgfSBmcm9tICcuLi9zcmMvY29udGV4dC9GaWx0ZXJDYXJNb2RlbFByb3ZpZGVyJztcblxuY29uc3QgSG9tZVBhZ2UgPSAoeyBDb21wb25lbnQsIHBhZ2VQcm9wcyB9OiBBcHBQcm9wcykgPT4ge1xuICAgIHJldHVybiAoXG4gICAgICAgIDxTdHlsZVByb3ZpZGVyPlxuICAgICAgICAgICAgPFRoZW1lUGlja2VyPlxuICAgICAgICAgICAgICAgIDxSZWFjdC5TdHJpY3RNb2RlPlxuICAgICAgICAgICAgICAgICAgICA8RmlsdGVyQ2FyTW9kZWxQcm92aWRlcj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxDb21wb25lbnQgey4uLnBhZ2VQcm9wc30gLz5cbiAgICAgICAgICAgICAgICAgICAgPC9GaWx0ZXJDYXJNb2RlbFByb3ZpZGVyPlxuICAgICAgICAgICAgICAgIDwvUmVhY3QuU3RyaWN0TW9kZT5cbiAgICAgICAgICAgIDwvVGhlbWVQaWNrZXI+XG4gICAgICAgIDwvU3R5bGVQcm92aWRlcj5cbiAgICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgSG9tZVBhZ2U7XG4iXSwibmFtZXMiOlsiUmVhY3QiLCJTdHlsZVByb3ZpZGVyIiwiVGhlbWVQaWNrZXIiLCJGaWx0ZXJDYXJNb2RlbFByb3ZpZGVyIiwiSG9tZVBhZ2UiLCJDb21wb25lbnQiLCJwYWdlUHJvcHMiLCJTdHJpY3RNb2RlIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/_app.tsx\n");

/***/ }),

/***/ "./src/context/FilterCarModelProvider.tsx":
/*!************************************************!*\
  !*** ./src/context/FilterCarModelProvider.tsx ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"FilterCarModelContext\": () => (/* binding */ FilterCarModelContext),\n/* harmony export */   \"FilterCarModelProvider\": () => (/* binding */ FilterCarModelProvider)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst FilterCarModelContext = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createContext({\n    queryString: \"\",\n    selectedBodyType: \"\",\n    setQueryString: ()=>{},\n    setSelectedBodyType: ()=>{}\n});\nconst FilterCarModelProvider = ({ children  })=>{\n    const { 0: selectedBodyType , 1: setSelectedBodyType  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(\"\");\n    const { 0: queryString , 1: setQueryString  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(\"\");\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(FilterCarModelContext.Provider, {\n        value: {\n            selectedBodyType,\n            setSelectedBodyType,\n            queryString,\n            setQueryString\n        },\n        children: children\n    }, void 0, false, {\n        fileName: \"/Users/creware/Desktop/Volvo/god-frontend-code-test/src/context/FilterCarModelProvider.tsx\",\n        lineNumber: 23,\n        columnNumber: 5\n    }, undefined);\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29udGV4dC9GaWx0ZXJDYXJNb2RlbFByb3ZpZGVyLnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQTtBQUEyRDtBQVNwRCxNQUFNRSxxQkFBcUIsaUJBQ2hDRiwwREFBbUIsQ0FBNEI7SUFDN0NJLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLGdCQUFnQixFQUFFLEVBQUU7SUFDcEJDLGNBQWMsRUFBRSxJQUFNLEVBQUU7SUFDeEJDLG1CQUFtQixFQUFFLElBQU0sRUFBRTtDQUM5QixDQUFDLENBQUM7QUFFRSxNQUFNQyxzQkFBc0IsR0FBRyxDQUFDLEVBQUVDLFFBQVEsR0FBeUIsR0FBSztJQUM3RSxNQUFNLEtBQUNKLGdCQUFnQixNQUFFRSxtQkFBbUIsTUFBSU4sK0NBQVEsQ0FBUyxFQUFFLENBQUM7SUFDcEUsTUFBTSxLQUFDRyxXQUFXLE1BQUVFLGNBQWMsTUFBSUwsK0NBQVEsQ0FBUyxFQUFFLENBQUM7SUFFMUQscUJBQ0UsOERBQUNDLHFCQUFxQixDQUFDUSxRQUFRO1FBQzdCQyxLQUFLLEVBQUU7WUFDTE4sZ0JBQWdCO1lBQ2hCRSxtQkFBbUI7WUFDbkJILFdBQVc7WUFDWEUsY0FBYztTQUNmO2tCQUVBRyxRQUFROzs7OztpQkFDc0IsQ0FDakM7Q0FDSCxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZnJvbnRlbmQtY29kZS10ZXN0Ly4vc3JjL2NvbnRleHQvRmlsdGVyQ2FyTW9kZWxQcm92aWRlci50c3g/YTk1NCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgUHJvcHNXaXRoQ2hpbGRyZW4sIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5cbnR5cGUgRmlsdGVyQ2FyTW9kZWxDb250ZXh0VHlwZSA9IHtcbiAgc2VsZWN0ZWRCb2R5VHlwZTogc3RyaW5nO1xuICBxdWVyeVN0cmluZzogc3RyaW5nO1xuICBzZXRRdWVyeVN0cmluZzogUmVhY3QuRGlzcGF0Y2g8UmVhY3QuU2V0U3RhdGVBY3Rpb248c3RyaW5nPj47XG4gIHNldFNlbGVjdGVkQm9keVR5cGU6IFJlYWN0LkRpc3BhdGNoPFJlYWN0LlNldFN0YXRlQWN0aW9uPHN0cmluZz4+O1xufTtcblxuZXhwb3J0IGNvbnN0IEZpbHRlckNhck1vZGVsQ29udGV4dCA9XG4gIFJlYWN0LmNyZWF0ZUNvbnRleHQ8RmlsdGVyQ2FyTW9kZWxDb250ZXh0VHlwZT4oe1xuICAgIHF1ZXJ5U3RyaW5nOiBcIlwiLFxuICAgIHNlbGVjdGVkQm9keVR5cGU6IFwiXCIsXG4gICAgc2V0UXVlcnlTdHJpbmc6ICgpID0+IHt9LFxuICAgIHNldFNlbGVjdGVkQm9keVR5cGU6ICgpID0+IHt9LFxuICB9KTtcblxuZXhwb3J0IGNvbnN0IEZpbHRlckNhck1vZGVsUHJvdmlkZXIgPSAoeyBjaGlsZHJlbiB9OiBQcm9wc1dpdGhDaGlsZHJlbjx7fT4pID0+IHtcbiAgY29uc3QgW3NlbGVjdGVkQm9keVR5cGUsIHNldFNlbGVjdGVkQm9keVR5cGVdID0gdXNlU3RhdGU8c3RyaW5nPihcIlwiKTtcbiAgY29uc3QgW3F1ZXJ5U3RyaW5nLCBzZXRRdWVyeVN0cmluZ10gPSB1c2VTdGF0ZTxzdHJpbmc+KFwiXCIpO1xuXG4gIHJldHVybiAoXG4gICAgPEZpbHRlckNhck1vZGVsQ29udGV4dC5Qcm92aWRlclxuICAgICAgdmFsdWU9e3tcbiAgICAgICAgc2VsZWN0ZWRCb2R5VHlwZSxcbiAgICAgICAgc2V0U2VsZWN0ZWRCb2R5VHlwZSxcbiAgICAgICAgcXVlcnlTdHJpbmcsXG4gICAgICAgIHNldFF1ZXJ5U3RyaW5nLFxuICAgICAgfX1cbiAgICA+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9GaWx0ZXJDYXJNb2RlbENvbnRleHQuUHJvdmlkZXI+XG4gICk7XG59O1xuIl0sIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJGaWx0ZXJDYXJNb2RlbENvbnRleHQiLCJjcmVhdGVDb250ZXh0IiwicXVlcnlTdHJpbmciLCJzZWxlY3RlZEJvZHlUeXBlIiwic2V0UXVlcnlTdHJpbmciLCJzZXRTZWxlY3RlZEJvZHlUeXBlIiwiRmlsdGVyQ2FyTW9kZWxQcm92aWRlciIsImNoaWxkcmVuIiwiUHJvdmlkZXIiLCJ2YWx1ZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/context/FilterCarModelProvider.tsx\n");

/***/ }),

/***/ "./src/css/styles.css":
/*!****************************!*\
  !*** ./src/css/styles.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "vcc-ui":
/*!*************************!*\
  !*** external "vcc-ui" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("vcc-ui");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.tsx"));
module.exports = __webpack_exports__;

})();