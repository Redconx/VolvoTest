"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/learn/[id]";
exports.ids = ["pages/learn/[id]"];
exports.modules = {

/***/ "./pages/learn/[id].tsx":
/*!******************************!*\
  !*** ./pages/learn/[id].tsx ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var vcc_ui__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! vcc-ui */ \"vcc-ui\");\n/* harmony import */ var vcc_ui__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(vcc_ui__WEBPACK_IMPORTED_MODULE_3__);\n\n\n\n\nconst Learn = ()=>{\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();\n    const { id  } = router.query;\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(vcc_ui__WEBPACK_IMPORTED_MODULE_3__.Flex, {\n        extend: {},\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(vcc_ui__WEBPACK_IMPORTED_MODULE_3__.Text, {\n                children: [\n                    \" Learn about \",\n                    id\n                ]\n            }, void 0, true, {\n                fileName: \"/Users/creware/Desktop/Volvo/god-frontend-code-test/pages/learn/[id].tsx\",\n                lineNumber: 11,\n                columnNumber: 13\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(vcc_ui__WEBPACK_IMPORTED_MODULE_3__.Link, {\n                type: \"button\",\n                onClick: ()=>router.back(),\n                children: \"Back\"\n            }, void 0, false, {\n                fileName: \"/Users/creware/Desktop/Volvo/god-frontend-code-test/pages/learn/[id].tsx\",\n                lineNumber: 12,\n                columnNumber: 13\n            }, undefined)\n        ]\n    }, void 0, true, {\n        fileName: \"/Users/creware/Desktop/Volvo/god-frontend-code-test/pages/learn/[id].tsx\",\n        lineNumber: 10,\n        columnNumber: 9\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Learn);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9sZWFybi9baWRdLnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7QUFBQTtBQUEwQjtBQUNjO0FBQ1E7QUFFaEQsTUFBTUssS0FBSyxHQUFHLElBQU07SUFDaEIsTUFBTUMsTUFBTSxHQUFHTCxzREFBUyxFQUFFO0lBQzFCLE1BQU0sRUFBRU0sRUFBRSxHQUFFLEdBQUdELE1BQU0sQ0FBQ0UsS0FBSztJQUUzQixxQkFDSSw4REFBQ0wsd0NBQUk7UUFBQ00sTUFBTSxFQUFFLEVBQUU7OzBCQUNaLDhEQUFDTCx3Q0FBSTs7b0JBQUMsZUFBYTtvQkFBQ0csRUFBRTs7Ozs7O3lCQUFROzBCQUM5Qiw4REFBQ0wsd0NBQUk7Z0JBQUNRLElBQUksRUFBQyxRQUFRO2dCQUFDQyxPQUFPLEVBQUUsSUFBTUwsTUFBTSxDQUFDTSxJQUFJLEVBQUU7MEJBQUUsTUFFbEQ7Ozs7O3lCQUFPOzs7Ozs7aUJBQ0osQ0FDVDtDQUNMO0FBRUQsaUVBQWVQLEtBQUssRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2Zyb250ZW5kLWNvZGUtdGVzdC8uL3BhZ2VzL2xlYXJuL1tpZF0udHN4PzFiN2YiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gJ25leHQvcm91dGVyJztcbmltcG9ydCB7IFZpZXcsIExpbmssIEZsZXgsIFRleHQgfSBmcm9tICd2Y2MtdWknO1xuXG5jb25zdCBMZWFybiA9ICgpID0+IHtcbiAgICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcbiAgICBjb25zdCB7IGlkIH0gPSByb3V0ZXIucXVlcnk7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8RmxleCBleHRlbmQ9e3t9fT5cbiAgICAgICAgICAgIDxUZXh0PiBMZWFybiBhYm91dCB7aWR9PC9UZXh0PlxuICAgICAgICAgICAgPExpbmsgdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHJvdXRlci5iYWNrKCl9PlxuICAgICAgICAgICAgICAgIEJhY2tcbiAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgPC9GbGV4PlxuICAgICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBMZWFybjtcbiJdLCJuYW1lcyI6WyJSZWFjdCIsInVzZVJvdXRlciIsIkxpbmsiLCJGbGV4IiwiVGV4dCIsIkxlYXJuIiwicm91dGVyIiwiaWQiLCJxdWVyeSIsImV4dGVuZCIsInR5cGUiLCJvbkNsaWNrIiwiYmFjayJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/learn/[id].tsx\n");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "vcc-ui":
/*!*************************!*\
  !*** external "vcc-ui" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("vcc-ui");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/learn/[id].tsx"));
module.exports = __webpack_exports__;

})();