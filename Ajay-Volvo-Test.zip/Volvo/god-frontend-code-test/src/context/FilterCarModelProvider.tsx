import React, { PropsWithChildren, useState } from "react";

type FilterCarModelContextType = {
  selectedBodyType: string;
  queryString: string;
  setQueryString: React.Dispatch<React.SetStateAction<string>>;
  setSelectedBodyType: React.Dispatch<React.SetStateAction<string>>;
};

export const FilterCarModelContext =
  React.createContext<FilterCarModelContextType>({
    queryString: "",
    selectedBodyType: "",
    setQueryString: () => {},
    setSelectedBodyType: () => {},
  });

export const FilterCarModelProvider = ({ children }: PropsWithChildren<{}>) => {
  const [selectedBodyType, setSelectedBodyType] = useState<string>("");
  const [queryString, setQueryString] = useState<string>("");

  return (
    <FilterCarModelContext.Provider
      value={{
        selectedBodyType,
        setSelectedBodyType,
        queryString,
        setQueryString,
      }}
    >
      {children}
    </FilterCarModelContext.Provider>
  );
};
