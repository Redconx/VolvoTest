import axios from 'axios';

const baseURL = 'https://66e1b097c831c8811b560513.mockapi.io/'; // my mocked endpoint.

const apiService = {
  get: async <T>(url: string, params?: any): Promise<T> => {
    try {
      const response = await axios.get<T>(`${baseURL}${url}`, { params });
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  post: async <T>(url: string, data?: any): Promise<T> => {
    try {
      const response = await axios.post<T>(`${baseURL}${url}`, data);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  put: async <T>(url: string, data?: any): Promise<T> => {
    try {
      const response = await axios.put<T>(`${baseURL}${url}`, data);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  delete: async <T>(url: string): Promise<T> => {
    try {
      const response = await axios.delete<T>(`${baseURL}${url}`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },
};

export default apiService;