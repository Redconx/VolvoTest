import { ExtendCSS } from 'vcc-ui';

export const containerStyle: ExtendCSS = {
    padding: '10px',
    // backgroundColor: '#f5f5f5',
    borderRadius: '4px',
    display: 'flex',
    alignItems: 'center',
    // boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
};

export const inputStyle: ExtendCSS = {
    border: '1px solid #ddd',
    borderRadius: '4px',
    padding: '8px',
    width: '100%',
    fontSize: '14px',
    transition: 'border-color 0.2s ease',
    ':focus': {
        borderColor: '#007bff',
        outline: 'none',
    },
};
