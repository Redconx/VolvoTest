import React, { useContext } from 'react';
import { Flex, TextInput} from 'vcc-ui'; // Assuming you have an Input component
import { FilterCarModelContext } from '../../context/FilterCarModelProvider';
import { containerStyle, inputStyle } from './CustomSearchInput.styles';

const CustomSearchInput = () => {
    const { queryString, setQueryString } = useContext(FilterCarModelContext);

    return (
        <Flex extend={containerStyle}>
            <TextInput
                value={queryString}
                onChange={(e) => setQueryString(e.target.value)}
                label="Search for cars..."
                // extend={inputStyle}
            />
        </Flex>
    );
};

export default CustomSearchInput;
