import React from "react";
import { Text, Spacer, Block, Flex, Link, useTheme } from "vcc-ui";
import Image from "next/image";
import {
  cardWrapper,
  textWrapper,
  imageWrapper,
  linksWrapper,
  bodyStyleText,
  modelStyleText,
  additionalStyles,
  additionallinksWrapper,
} from "./CarCard.styles";
import { Car } from "../../utils/interfaces/cars";
import { useMediaQuery } from "@mui/material";

type CarProps = {
  car: Car;
};

enum PageRoutes {
  DETAILS = "/learn",
  PURCHASE = "/shop",
}

export const CarCard = ({ car }: CarProps) => {
  const { id, modelType, bodyType, modelName, imageUrl } = car;
  const mobileScreen = useMediaQuery("(max-width : 800px)");
  // console.log(mobileScreen,modelType,"Model type")
  // const { breakpoints } = useTheme();

  return (
    <Block extend={cardWrapper} aria-label={`Car details for ${modelName}`}>
      <header>
        <Text subStyle="emphasis" extend={bodyStyleText}>
          {bodyType}
        </Text>
        <Flex extend={mobileScreen ? additionalStyles : textWrapper}>
          <Text
            as="h2"
            subStyle="emphasis"
            extend={{ marginRight: 3 }}
            aria-label={`Model name: ${modelName}`}
          >
            {modelName}
          </Text>
          <Text
            as="h3"
            variant="columbus"
            subStyle="standard"
            extend={modelStyleText}
            aria-label={`Model type: ${modelType}`}
          >
            {modelType}
          </Text>
        </Flex>
      </header>

      <Spacer size={4} />

      <Flex extend={imageWrapper}>
        <Link
          href={`${PageRoutes.DETAILS}/${id}`}
          aria-label={`Learn more about ${modelName}`}
        >
          <Image
            src={imageUrl}
            alt={`Volvo ${modelName}`}
            layout="responsive"
            objectFit="contain"
            width={400}
            height={350}
            priority
          />
        </Link>
      </Flex>

      <Flex extend={linksWrapper}>
        <Link
          href={`${PageRoutes.DETAILS}/${id}`}
          arrow="right"
          style={mobileScreen ? { fontSize: 12 } : {}}
          aria-label={`Learn more about ${modelName}`}
        >
          Learn More
        </Link>
        <Link
          href={`${PageRoutes.PURCHASE}/${id}`}
          arrow="right"
          style={mobileScreen ? { fontSize: 12 } : {}}
          aria-label={`Shop for ${modelName}`}
        >
          Shop Now
        </Link>
      </Flex>
    </Block>
  );
};
