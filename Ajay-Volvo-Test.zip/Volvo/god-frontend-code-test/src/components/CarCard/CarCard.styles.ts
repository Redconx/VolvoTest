import { useTheme } from '@emotion/react';
import { ExtendCSS, CurrentTheme, ThemeBreakpointName } from 'vcc-ui';

export const cardWrapper: ExtendCSS = {
    // backgroundColor: '#f9f9f9',
    borderRadius: '8px',
    padding: '10px 15px',
};
export const textWrapper: ExtendCSS = {
    flexDirection: 'row',
    alignItems: 'center',
    textAlign: 'left'

}
export const additionalStyles: ExtendCSS = {
    // border:'1px solid red',
    flexDirection: 'column',
    alignItems: 'flex-start',
    fontSize: '12px'
}
export const imageWrapper: ExtendCSS = {
    // border: '1px solid #ddd',
    marginTop: '16px',
};

export const linksWrapper: ExtendCSS = {
    flexDirection: 'row',
    alignItems: 'center',
    textAlign: 'center',
    justifyContent: 'space-around',
    paddingBottom: '45px',
};
export const additionallinksWrapper: ExtendCSS = {
    flexDirection: 'row',
    alignItems: 'center',
    textAlign: 'center',
    justifyContent: 'space-around',
    paddingBottom: '45px',
    fontSize:'50px',
    border:'1px solid red'
};

export const bodyStyleText: ExtendCSS = ({ theme }: { theme: CurrentTheme }) => ({
    color: theme.color.foreground.secondary,
    textTransform: 'capitalize',
});

export const modelStyleText: ExtendCSS = ({ theme }: { theme: CurrentTheme }) => ({
    color: theme.color.foreground.secondary,
});
