import { useState } from "react";
import { Swiper, SwiperSlide, SwiperClass } from "swiper/react";
import { Block, Flex, Spacer, Text } from "vcc-ui";
import { Pagination } from "swiper/modules";
import "swiper/css";
import "swiper/css/pagination";
import { useMediaQuery } from "@mui/material";
import PrevSlideBtn from "../Buttons/PrevSlideBtn";
import NextSlideBtn from "../Buttons/NextSlideBtn";
import { Car } from "../../utils/interfaces/cars";
import { btnWrapper, sliderWrapper } from "./CarComponent.styles";
import { CarCard } from "./CarCard";

type CarSliderProps = {
  cars: Car[];
};

const defaultSize = 4;

export const CarComponent = ({ cars }: CarSliderProps) => {
  const mediumScreen = useMediaQuery("(min-width : 480px)");
  const desktopScreen = useMediaQuery("(min-width : 1024px)");
  // console.log(cars, "Im cars")
  const [prevBtnDisabled, setPrevBtnDisabled] = useState(true);
  const [nextBtnDisabled, setNextBtnDisabled] = useState(false);
  const [swiperRef, setSwiperRef] = useState<SwiperClass>();

  const slidesPerView = desktopScreen ? 4 : mediumScreen ? 2.4 : 1.3;

  //  we show nav btn if on desktop
  const showNavigationBtn = desktopScreen && cars.length > defaultSize;

  // handling slide change
  const handleSlideChange = (swiper: { activeIndex: number }) => {
    setPrevBtnDisabled(swiper.activeIndex === 0);
    setNextBtnDisabled(swiper.activeIndex === cars.length - defaultSize);
  };

  // we are attaching swiper event handler so that we can handle swipes on click also of our nav button
  swiperRef?.on("slideChange", handleSlideChange);

  if (cars.length === 0) {
    return (
      <Block extend={sliderWrapper}>
        <Text
          as="h2"
          subStyle="emphasis"
          extend={{ textAlign: "center", marginTop: "20px" }}
        >
          Oops! No cars available. Try other filters.
        </Text>
      </Block>
    );
  }

  return (
    <Block extend={sliderWrapper}>
      <Swiper
        // className="mySwiper"
        onSwiper={setSwiperRef}
        spaceBetween={10}
        modules={[Pagination]}
        pagination={!showNavigationBtn}
        slidesPerView={slidesPerView}
        speed={500}
        navigation={true}
        aria-live="polite"
      >
        {cars.map((car) => (
          <SwiperSlide key={car.id}>
            <CarCard car={car} />
          </SwiperSlide>
        ))}
      </Swiper>

      {showNavigationBtn && (
        <Flex extend={btnWrapper}>
          <PrevSlideBtn
            disabled={prevBtnDisabled}
            onClick={() => swiperRef?.slidePrev()}
          />
          <Spacer size={3} />
          <NextSlideBtn
            disabled={nextBtnDisabled}
            onClick={() => swiperRef?.slideNext()}
          />
        </Flex>
      )}
    </Block>
  );
};
