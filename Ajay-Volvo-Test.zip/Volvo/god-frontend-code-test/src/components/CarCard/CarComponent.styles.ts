import { ExtendCSS } from 'vcc-ui';


export const sliderWrapper: ExtendCSS = {
    backgroundColor: '#ffffff',
    borderRadius: '5px',
    padding: '30px 26px 60px',
    margin: '40px 0',
};

export const btnWrapper: ExtendCSS = {
    paddingTop: '10px',
    justifyContent: 'flex-end',
    flexDirection: 'row',
};
