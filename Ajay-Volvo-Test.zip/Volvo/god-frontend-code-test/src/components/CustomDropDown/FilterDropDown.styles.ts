import { ExtendCSS } from 'vcc-ui';

export const dropdownContainer: ExtendCSS = {
    padding: '10px',
    color: '#333',
    // backgroundColor: '#f4f4f4',
    borderRadius: '4px',
};
