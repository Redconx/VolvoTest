import React, { useContext } from 'react';
import { SelectInput, Flex, Block, useTheme } from 'vcc-ui';
import { FilterCarModelContext } from '../../context/FilterCarModelProvider';
import { dropdownContainer } from './FilterDropDown.styles';

type FilterCarModelsProps = {
    bodyTypes: string[];
};

const FilterDropDown = ({ bodyTypes }: FilterCarModelsProps) => {
    const { selectedBodyType, setSelectedBodyType } = useContext(FilterCarModelContext);

    return (
        <Flex extend={dropdownContainer}>
            <Block
            >
                <SelectInput
                    value={selectedBodyType}
                    onChange={(e) => setSelectedBodyType(e.target.value)}
                    allowEmpty
                    label="Choose a body type"
                >
                    {bodyTypes.map((type, idx) => (
                        <option key={idx} value={type}>
                            {type}
                        </option>
                    ))}
                </SelectInput>
            </Block>
        </Flex>
    );
};

export default FilterDropDown;
