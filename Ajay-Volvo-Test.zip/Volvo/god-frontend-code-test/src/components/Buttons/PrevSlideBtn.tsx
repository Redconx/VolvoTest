import { IconButton } from 'vcc-ui';

type PrevBtnProps = {
    disabled: boolean;
    onClick: () => void;
};

const PrevSlideBtn = ({ disabled, onClick }: PrevBtnProps) => {
    return (
        <IconButton
            onClick={onClick}
            aria-disabled={disabled}
            aria-label="Previous car"
            variant="outline"
            iconName="navigation-chevronback"
        ></IconButton>
    );
};

export default PrevSlideBtn;
