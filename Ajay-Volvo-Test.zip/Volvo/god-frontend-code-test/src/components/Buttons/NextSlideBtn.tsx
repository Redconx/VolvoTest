import { IconButton } from 'vcc-ui';

type NextBtnProps = {
    disabled: boolean;
    onClick: () => void;
};

const NextSlideBtn = ({ disabled, onClick }: NextBtnProps) => {
    return (
        <IconButton
            iconName="navigation-chevronforward"
            onClick={onClick}
            variant="outline"
            aria-disabled={disabled}
            aria-label="Next car"
        ></IconButton>
    );
};

export default NextSlideBtn;
