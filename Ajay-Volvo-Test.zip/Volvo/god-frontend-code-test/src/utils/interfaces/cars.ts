export type Car = {
    id: string;
    bodyType: string;
    modelName: string;
    imageUrl: string;
    modelType: string;
};
