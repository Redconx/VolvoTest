import { Car } from "./interfaces/cars";

export function getFilteredCars(cars: Car[] | undefined, searchTerm: string): Car[] {

    // console.log(cars,searchTerm,"Hello filter")
    if (!cars) return [];

    const query = searchTerm.trim().toLowerCase();
    // debugger

    return cars.filter(car => car.bodyType.toLowerCase().includes(query));
}
